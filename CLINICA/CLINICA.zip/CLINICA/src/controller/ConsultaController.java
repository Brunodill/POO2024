package controller;

import dao.ConsultaDAO;
import model.Consulta;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class ConsultaController {

    private ConsultaDAO consultaDAO;

    public ConsultaController() {
        this.consultaDAO = new ConsultaDAO();
    }

    // Agendar consulta
    public void agendarConsulta(LocalDate data, LocalTime hora, int pacienteId, int profissionalId, String motivo) {
        Consulta consulta = new Consulta();
        consulta.setData(data);
        consulta.setHora(hora);
        consulta.setPacienteId(pacienteId);
        consulta.setProfissionalId(profissionalId);
        consulta.setMotivo(motivo);
        consultaDAO.inserir(consulta);
    }

    // Listar todas as consultas
    public List<Consulta> listarConsultas() {
        return consultaDAO.listarTodas();
    }

    // Atualizar consulta
    public void atualizarConsulta(int id, LocalDate data, LocalTime hora, int pacienteId, int profissionalId, String motivo) {
        Consulta consulta = new Consulta();
        consulta.setId(id);
        consulta.setData(data);
        consulta.setHora(hora);
        consulta.setPacienteId(pacienteId);
        consulta.setProfissionalId(profissionalId);
        consulta.setMotivo(motivo);
        consultaDAO.atualizar(consulta);
    }

    // Excluir consulta
    public void excluirConsulta(int id) {
        consultaDAO.excluir(id);
    }
}
