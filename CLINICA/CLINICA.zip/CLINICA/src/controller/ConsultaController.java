package controller;

import dao.ConsultaDAO;
import model.Consulta;
import model.Paciente;
import model.Profissional;

import java.util.Date;
import java.util.List;

public class ConsultaController {
    private ConsultaDAO consultaDAO;

    public ConsultaController(ConsultaDAO consultaDAO) {
        this.consultaDAO = consultaDAO;
    }

    public void agendarConsulta(Date data, String hora, Paciente paciente, Profissional profissional, String motivo) {
        Consulta consulta = new Consulta();
        consulta.setData(data);
        consulta.setHora(hora);
        consulta.setPaciente(paciente);
        consulta.setProfissional(profissional);
        consulta.setMotivo(motivo);

        consultaDAO.salvar(consulta);
    }

    public List<Consulta> listarConsultas() {
        return consultaDAO.listar();
    }
}

