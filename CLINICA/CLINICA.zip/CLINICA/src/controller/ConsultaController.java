package controller;

import dao.ConsultaDAO;
import dao.PacienteDAO;
import dao.ProfissionalDAO;
import model.Consulta;
import model.Paciente;
import model.Profissional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class ConsultaController {

    private ConsultaDAO consultaDAO;
    private PacienteDAO pacienteDAO;
    private ProfissionalDAO profissionalDAO;

    public ConsultaController() {
        this.consultaDAO = new ConsultaDAO();
        this.pacienteDAO = new PacienteDAO();
        this.profissionalDAO = new ProfissionalDAO();
    }

    // Agendar consulta
    public void agendarConsulta(LocalDate data, LocalTime hora, int pacienteId, int profissionalId, String motivo) {
        Consulta consulta = new Consulta();
        consulta.setData(data);
        consulta.setHora(hora);
        consulta.setPacienteId(pacienteId);
        consulta.setProfissionalId(profissionalId);
        consulta.setMotivo(motivo);
        consultaDAO.inserir(consulta);
    }

    // Listar pacientes
    public List<Paciente> listarPacientes() {
        return pacienteDAO.listarTodos();
    }

    // Listar profissionais
    public List<Profissional> listarProfissionais() {
        return profissionalDAO.listarTodos();
    }
}
