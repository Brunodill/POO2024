package controller;

import dao.AgendaDAO;
import model.Agenda;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class AgendaController {

    private AgendaDAO agendaDAO;

    public AgendaController() {
        this.agendaDAO = new AgendaDAO();
    }

    // Adicionar horário à agenda
    public void adicionarAgenda(LocalDate dia, LocalTime hora, int profissionalId, boolean disponibilidade) {
        Agenda agenda = new Agenda();
        agenda.setDia(dia);
        agenda.setHora(hora);
        agenda.setProfissionalId(profissionalId);
        agenda.setDisponibilidade(disponibilidade);
        agendaDAO.inserir(agenda);
    }

    // Listar todas as agendas
    public List<Agenda> listarAgendas() {
        return agendaDAO.listarTodas();
    }

    // Atualizar agenda
    public void atualizarAgenda(int id, LocalDate dia, LocalTime hora, int profissionalId, boolean disponibilidade) {
        Agenda agenda = new Agenda();
        agenda.setId(id);
        agenda.setDia(dia);
        agenda.setHora(hora);
        agenda.setProfissionalId(profissionalId);
        agenda.setDisponibilidade(disponibilidade);
        agendaDAO.atualizar(agenda);
    }

    // Excluir agenda
    public void excluirAgenda(int id) {
        agendaDAO.excluir(id);
    }
}
