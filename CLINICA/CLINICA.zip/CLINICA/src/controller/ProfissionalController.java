package controller;

import dao.ProfissionalDAO;
import model.Profissional;

public class ProfissionalController {
    private ProfissionalDAO profissionalDAO;

    public ProfissionalController(ProfissionalDAO QprofissionalDAO) {
        this.profissionalDAO = profissionalDAO;
    }

    public void cadastrarProfissional(String nome, String CRM, String areaDeAtuacao) {
        Profissional profissional = new Profissional();
        profissional.setNome(nome);
        profissional.setCRM(CRM);
        profissional.setAreaDeAtuacao(areaDeAtuacao);

        profissionalDAO.salvar(profissional);
    }

    public Profissional buscarProfissional(String CRM) {
        return profissionalDAO.buscarPorCRM(CRM);
    }

    public void atualizarProfissional(Profissional profissional) {
        profissionalDAO.atualizar(profissional);
    }

    public void removerProfissional(String CRM) {
        profissionalDAO.remover(CRM);
    }
}

