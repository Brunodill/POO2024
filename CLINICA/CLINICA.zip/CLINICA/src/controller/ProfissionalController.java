package controller;

import dao.ProfissionalDAO;
import model.Profissional;
import java.util.List;

public class ProfissionalController {

    private ProfissionalDAO profissionalDAO;

    public ProfissionalController() {
        this.profissionalDAO = new ProfissionalDAO();
    }

    // Adicionar profissional
    public void adicionarProfissional(String nome, String crm, String areaDeAtuacao) {
        Profissional profissional = new Profissional();
        profissional.setNome(nome);
        profissional.setCrm(crm);
        profissional.setAreaDeAtuacao(areaDeAtuacao);
        profissionalDAO.inserir(profissional);
    }

    // Listar todos os profissionais
    public List<Profissional> listarProfissionais() {
        return profissionalDAO.listarTodos();
    }

    // Atualizar profissional
    public void atualizarProfissional(int id, String nome, String crm, String areaDeAtuacao) {
        Profissional profissional = new Profissional();
        profissional.setId(id);
        profissional.setNome(nome);
        profissional.setCrm(crm);
        profissional.setAreaDeAtuacao(areaDeAtuacao);
        profissionalDAO.atualizar(profissional);
    }

    // Excluir profissional
    public void excluirProfissional(int id) {
        profissionalDAO.excluir(id);
    }
}
