package controller;

import dao.PacienteDAO;
import model.Paciente;

public class PacienteController {
    private PacienteDAO pacienteDAO;

    public PacienteController(PacienteDAO pacienteDAO) {
        this.pacienteDAO = pacienteDAO;
    }

    public void cadastrarPaciente(String nome, int idade, String sexo, String endereco, String telefone, String email) {
        Paciente paciente = new Paciente();
        paciente.setNome(nome);
        paciente.setIdade(idade);
        paciente.setSexo(sexo);
        paciente.setEndereco(endereco);
        paciente.setTelefone(telefone);
        paciente.setEmail(email);

        pacienteDAO.salvar(paciente);
    }

    public Paciente buscarPaciente(String email) {
        return pacienteDAO.buscarPorEmail(email);
    }

    public void atualizarPaciente(Paciente paciente) {
        pacienteDAO.atualizar(paciente);
    }

    public void removerPaciente(String email) {
        pacienteDAO.remover(email);
    }
}

