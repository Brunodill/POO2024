package controller;

import dao.PacienteDAO;
import model.Paciente;
import java.util.List;

public class PacienteController {

    private PacienteDAO pacienteDAO;

    public PacienteController() {
        this.pacienteDAO = new PacienteDAO();
    }

    // Adicionar paciente
    public void adicionarPaciente(String nome, int idade, String sexo, String endereco, String telefone, String email) {
        Paciente paciente = new Paciente();
        paciente.setNome(nome);
        paciente.setIdade(idade);
        paciente.setSexo(sexo);
        paciente.setEndereco(endereco);
        paciente.setTelefone(telefone);
        paciente.setEmail(email);
        pacienteDAO.inserir(paciente);
    }

    // Listar todos os pacientes
    public List<Paciente> listarPacientes() {
        return pacienteDAO.listarTodos();
    }

    // Atualizar paciente
    public void atualizarPaciente(int id, String nome, int idade, String sexo, String endereco, String telefone, String email) {
        Paciente paciente = new Paciente();
        paciente.setId(id);
        paciente.setNome(nome);
        paciente.setIdade(idade);
        paciente.setSexo(sexo);
        paciente.setEndereco(endereco);
        paciente.setTelefone(telefone);
        paciente.setEmail(email);
        pacienteDAO.atualizar(paciente);
    }

    // Excluir paciente
    public void excluirPaciente(int id) {
        pacienteDAO.excluir(id);
    }
}
