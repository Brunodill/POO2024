package view;

import controller.ConsultaController;
import controller.PacienteController;
import controller.ProfissionalController;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class AgendamentoConsultaView extends JFrame {

    private JComboBox<String> cbPacientes, cbProfissionais;
    private JTextField txtData, txtHora, txtMotivo;

    public AgendamentoConsultaView() {
        setTitle("Agendamento de Consultas");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Paciente
        JLabel lblPaciente = new JLabel("Paciente:");
        lblPaciente.setBounds(20, 20, 100, 30);
        add(lblPaciente);

        cbPacientes = new JComboBox<>();
        cbPacientes.setBounds(150, 20, 300, 30);
        carregarPacientes();
        add(cbPacientes);

        // Profissional
        JLabel lblProfissional = new JLabel("Profissional:");
        lblProfissional.setBounds(20, 70, 100, 30);
        add(lblProfissional);

        cbProfissionais = new JComboBox<>();
        cbProfissionais.setBounds(150, 70, 300, 30);
        carregarProfissionais();
        add(cbProfissionais);

        // Data
        JLabel lblData = new JLabel("Data (YYYY-MM-DD):");
        lblData.setBounds(20, 120, 150, 30);
        add(lblData);

        txtData = new JTextField();
        txtData.setBounds(150, 120, 300, 30);
        add(txtData);

        // Hora
        JLabel lblHora = new JLabel("Hora (HH:MM:SS):");
        lblHora.setBounds(20, 170, 150, 30);
        add(lblHora);

        txtHora = new JTextField();
        txtHora.setBounds(150, 170, 300, 30);
        add(txtHora);

        // Motivo
        JLabel lblMotivo = new JLabel("Motivo:");
        lblMotivo.setBounds(20, 220, 100, 30);
        add(lblMotivo);

        txtMotivo = new JTextField();
        txtMotivo.setBounds(150, 220, 300, 30);
        add(txtMotivo);

        // Botão de Agendar
        JButton btnAgendar = new JButton("Agendar");
        btnAgendar.setBounds(200, 300, 100, 30);
        btnAgendar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agendarConsulta();
            }
        });
        add(btnAgendar);
    }

    private void carregarPacientes() {
        PacienteController pacienteController = new PacienteController();
        List<String> pacientes = pacienteController.listarPacientes();
        for (String paciente : pacientes) {
            cbPacientes.addItem(paciente);
        }
    }

    private void carregarProfissionais() {
        ProfissionalController profissionalController = new ProfissionalController();
        List<String> profissionais = profissionalController.listarProfissionais();
        for (String profissional : profissionais) {
            cbProfissionais.addItem(profissional);
        }
    }

    private void agendarConsulta() {
        String pacienteSelecionado = cbPacientes.getSelectedItem().toString();
        String profissionalSelecionado = cbProfissionais.getSelectedItem().toString();
        String data = txtData.getText();
        String hora = txtHora.getText();
        String motivo = txtMotivo.getText();

        if (pacienteSelecionado.isEmpty() || profissionalSelecionado.isEmpty() || data.isEmpty() || hora.isEmpty() || motivo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ConsultaController consultaController = new ConsultaController();
        boolean sucesso = consultaController.agendarConsulta(pacienteSelecionado, profissionalSelecionado, data, hora, motivo);

        if (sucesso) {
            JOptionPane.showMessageDialog(this, "Consulta agendada com sucesso!");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao agendar consulta. Verifique os dados e tente novamente.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
