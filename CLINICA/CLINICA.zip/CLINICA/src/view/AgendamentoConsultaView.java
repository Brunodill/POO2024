package view;

import controller.ConsultaController;
import model.Paciente;
import model.Profissional;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;

public class AgendamentoConsultaView extends JFrame {

    private JComboBox<Paciente> cbPaciente;
    private JComboBox<Profissional> cbProfissional;
    private JSpinner spData;
    private JSpinner spHora;
    private JTextField tfMotivo;
    private ConsultaController consultaController;

    public AgendamentoConsultaView() {
        setTitle("Agendamento de Consulta");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        consultaController = new ConsultaController();

        // Label Paciente
        JLabel lblPaciente = new JLabel("Paciente:");
        lblPaciente.setBounds(30, 30, 100, 30);
        add(lblPaciente);

        // ComboBox para selecionar paciente
        cbPaciente = new JComboBox<>();
        cbPaciente.setBounds(120, 30, 200, 30);
        add(cbPaciente);

        // Label Profissional
        JLabel lblProfissional = new JLabel("Profissional:");
        lblProfissional.setBounds(30, 70, 100, 30);
        add(lblProfissional);

        // ComboBox para selecionar profissional
        cbProfissional = new JComboBox<>();
        cbProfissional.setBounds(120, 70, 200, 30);
        add(cbProfissional);

        // Label Data
        JLabel lblData = new JLabel("Data:");
        lblData.setBounds(30, 110, 100, 30);
        add(lblData);

        // Spinner para selecionar data
        spData = new JSpinner(new SpinnerDateModel());
        spData.setBounds(120, 110, 200, 30);
        add(spData);

        // Label Hora
        JLabel lblHora = new JLabel("Hora:");
        lblHora.setBounds(30, 150, 100, 30);
        add(lblHora);

        // Spinner para selecionar hora
        spHora = new JSpinner(new SpinnerDateModel());
        spHora.setBounds(120, 150, 200, 30);
        add(spHora);

        // Label Motivo
        JLabel lblMotivo = new JLabel("Motivo:");
        lblMotivo.setBounds(30, 190, 100, 30);
        add(lblMotivo);

        // Campo para inserir o motivo da consulta
        tfMotivo = new JTextField();
        tfMotivo.setBounds(120, 190, 200, 30);
        add(tfMotivo);

        // Botão para Agendar Consulta
        JButton btnAgendar = new JButton("Agendar Consulta");
        btnAgendar.setBounds(150, 240, 150, 30);
        btnAgendar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agendarConsulta();
            }
        });
        add(btnAgendar);

        carregarDados();

        setVisible(true);
    }

    // Carregar os dados de pacientes e profissionais
    private void carregarDados() {
        List<Paciente> pacientes = consultaController.listarPacientes();
        for (Paciente p : pacientes) {
            cbPaciente.addItem(p);
        }

        List<Profissional> profissionais = consultaController.listarProfissionais();
        for (Profissional p : profissionais) {
            cbProfissional.addItem(p);
        }
    }

    // Método para agendar consulta
    private void agendarConsulta() {
        Paciente paciente = (Paciente) cbPaciente.getSelectedItem();
        Profissional profissional = (Profissional) cbProfissional.getSelectedItem();
        
        // Obtendo data
        Date dataSelecionada = (Date) spData.getValue();
        LocalDate data = dataSelecionada.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
        
        // Obtendo hora
        Date horaSelecionada = (Date) spHora.getValue();
        LocalTime hora = horaSelecionada.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalTime();
        
        String motivo = tfMotivo.getText();

        // Agendando a consulta
        consultaController.agendarConsulta(data, hora, paciente.getId(), profissional.getId(), motivo);
        JOptionPane.showMessageDialog(this, "Consulta agendada com sucesso!");
        dispose();
    }
}
