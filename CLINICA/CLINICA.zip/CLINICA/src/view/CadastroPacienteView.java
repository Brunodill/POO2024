package view;

import controller.PacienteController;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastroPacienteView extends JFrame {

    private JTextField txtNome, txtIdade, txtSexo, txtEndereco, txtTelefone, txtEmail;

    public CadastroPacienteView() {
        setTitle("Cadastro de Paciente");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Nome
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(20, 20, 100, 30);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(150, 20, 200, 30);
        add(txtNome);

        // Idade
        JLabel lblIdade = new JLabel("Idade:");
        lblIdade.setBounds(20, 70, 100, 30);
        add(lblIdade);

        txtIdade = new JTextField();
        txtIdade.setBounds(150, 70, 200, 30);
        add(txtIdade);

        // Sexo
        JLabel lblSexo = new JLabel("Sexo:");
        lblSexo.setBounds(20, 120, 100, 30);
        add(lblSexo);

        txtSexo = new JTextField();
        txtSexo.setBounds(150, 120, 200, 30);
        add(txtSexo);

        // Endereço
        JLabel lblEndereco = new JLabel("Endereço:");
        lblEndereco.setBounds(20, 170, 100, 30);
        add(lblEndereco);

        txtEndereco = new JTextField();
        txtEndereco.setBounds(150, 170, 200, 30);
        add(txtEndereco);

        // Telefone
        JLabel lblTelefone = new JLabel("Telefone:");
        lblTelefone.setBounds(20, 220, 100, 30);
        add(lblTelefone);

        txtTelefone = new JTextField();
        txtTelefone.setBounds(150, 220, 200, 30);
        add(txtTelefone);

        // Email
        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(20, 270, 100, 30);
        add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(150, 270, 200, 30);
        add(txtEmail);

        // Botão de Salvar
        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(150, 320, 100, 30);
        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PacienteController controller = new PacienteController();
                controller.adicionarPaciente(
                    txtNome.getText(),
                    Integer.parseInt(txtIdade.getText()),
                    txtSexo.getText(),
                    txtEndereco.getText(),
                    txtTelefone.getText(),
                    txtEmail.getText()
                );
                JOptionPane.showMessageDialog(null, "Paciente cadastrado com sucesso!");
                dispose();
            }
        });
        add(btnSalvar);
    }
}
