package view;

import controller.PacienteController;
import dao.PacienteDAO;
import model.Paciente;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PacienteForm extends JFrame {
    private JTextField nomeField;
    private JTextField idadeField;
    private JTextField sexoField;
    private JTextField enderecoField;
    private JTextField telefoneField;
    private JTextField emailField;
    private JButton salvarButton;

    private PacienteController pacienteController;

    public PacienteForm(PacienteController controller) {
        this.pacienteController = controller;
        initialize();
    }

    private void initialize() {
        setTitle("Cadastro de Paciente");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2, 5, 5));

        panel.add(new JLabel("Nome:"));
        nomeField = new JTextField();
        panel.add(nomeField);

        panel.add(new JLabel("Idade:"));
        idadeField = new JTextField();
        panel.add(idadeField);

        panel.add(new JLabel("Sexo:"));
        sexoField = new JTextField();
        panel.add(sexoField);

        panel.add(new JLabel("Endereço:"));
        enderecoField = new JTextField();
        panel.add(enderecoField);

        panel.add(new JLabel("Telefone:"));
        telefoneField = new JTextField();
        panel.add(telefoneField);

        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);

        salvarButton = new JButton("Salvar");
        salvarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarPaciente();
            }
        });
        panel.add(salvarButton);

        add(panel);
    }

    private void salvarPaciente() {
        String nome = nomeField.getText();
        int idade = Integer.parseInt(idadeField.getText());
        String sexo = sexoField.getText();
        String endereco = enderecoField.getText();
        String telefone = telefoneField.getText();
        String email = emailField.getText();

        pacienteController.cadastrarPaciente(nome, idade, sexo, endereco, telefone, email);
        JOptionPane.showMessageDialog(this, "Paciente salvo com sucesso!");

        nomeField.setText("");
        idadeField.setText("");
        sexoField.setText("");
        enderecoField.setText("");
        telefoneField.setText("");
        emailField.setText("");
    }

    public static void main(String[] args) {
        PacienteController controller = new PacienteController(new PacienteDAO());
        PacienteForm form = new PacienteForm(controller);
        form.setVisible(true);
    }
}

