package view;

import controller.PacienteController;
import model.Paciente;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastrarPacienteView extends JFrame {
    private JTextField nomeField, idadeField, sexoField, enderecoField, telefoneField, emailField;
    private JButton salvarButton;

    private PacienteController pacienteController;

    public CadastrarPacienteView(PacienteController pacienteController) {
        this.pacienteController = pacienteController;
        
        setTitle("Cadastrar Paciente");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Componentes de entrada
        nomeField = new JTextField(20);
        idadeField = new JTextField(5);
        sexoField = new JTextField(10);
        enderecoField = new JTextField(20);
        telefoneField = new JTextField(15);
        emailField = new JTextField(20);
        salvarButton = new JButton("Salvar");

        // Layout
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(new JLabel("Nome:"));
        add(nomeField);
        add(new JLabel("Idade:"));
        add(idadeField);
        add(new JLabel("Sexo:"));
        add(sexoField);
        add(new JLabel("Endereço:"));
        add(enderecoField);
        add(new JLabel("Telefone:"));
        add(telefoneField);
        add(new JLabel("Email:"));
        add(emailField);
        add(salvarButton);

        // Ação do botão Salvar
        salvarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = nomeField.getText();
                int idade = Integer.parseInt(idadeField.getText());
                String sexo = sexoField.getText();
                String endereco = enderecoField.getText();
                String telefone = telefoneField.getText();
                String email = emailField.getText();

                Paciente paciente = new Paciente();
                paciente.setNome(nome);
                paciente.setIdade(idade);
                paciente.setSexo(sexo);
                paciente.setEndereco(endereco);
                paciente.setTelefone(telefone);
                paciente.setEmail(email);

                pacienteController.cadastrarPaciente(nome, idade, sexo, endereco, telefone, email);
                JOptionPane.showMessageDialog(CadastrarPacienteView.this, "Paciente cadastrado com sucesso!");
                dispose(); // Fechar a janela
            }
        });
    }
}
