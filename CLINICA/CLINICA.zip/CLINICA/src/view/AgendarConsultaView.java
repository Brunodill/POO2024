package view;

import controller.ConsultaController;
import model.Consulta;
import model.Paciente;
import model.Profissional;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class AgendarConsultaView extends JFrame {
    private JTextField dataField, horaField, motivoField;
    private JComboBox<Paciente> pacienteComboBox;
    private JComboBox<Profissional> profissionalComboBox;
    private JButton agendarButton;

    private ConsultaController consultaController;

    public AgendarConsultaView(ConsultaController consultaController, Paciente[] pacientes, Profissional[] profissionais) {
        this.consultaController = consultaController;

        setTitle("Agendar Consulta");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Componentes de entrada
        dataField = new JTextField(10);
        horaField = new JTextField(5);
        motivoField = new JTextField(20);
        pacienteComboBox = new JComboBox<>(pacientes);
        profissionalComboBox = new JComboBox<>(profissionais);
        agendarButton = new JButton("Agendar");

        // Layout
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(new JLabel("Data (dd/MM/yyyy):"));
        add(dataField);
        add(new JLabel("Hora:"));
        add(horaField);
        add(new JLabel("Motivo:"));
        add(motivoField);
        add(new JLabel("Paciente:"));
        add(pacienteComboBox);
        add(new JLabel("Profissional:"));
        add(profissionalComboBox);
        add(agendarButton);

        // Ação do botão Agendar
        agendarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String data = dataField.getText();
                    String hora = horaField.getText();
                    String motivo = motivoField.getText();
                    Paciente paciente = (Paciente) pacienteComboBox.getSelectedItem();
                    Profissional profissional = (Profissional) profissionalComboBox.getSelectedItem();

                    Date dataConsulta = new Date(data); // Aqui você pode usar SimpleDateFormat se necessário

                    consultaController.agendarConsulta(dataConsulta, hora, paciente, profissional, motivo);
                    JOptionPane.showMessageDialog(AgendarConsultaView.this, "Consulta agendada com sucesso!");
                    dispose(); // Fechar a janela
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(AgendarConsultaView.this, "Erro ao agendar a consulta!");
                }
            }
        });
    }

    // Método main para iniciar a aplicação
    public static void main(String[] args) {
        // Exemplo de criação de objetos (ajuste conforme necessário)
        Paciente[] pacientes = new Paciente[] { new Paciente("Paciente 1"), new Paciente("Paciente 2") };
        Profissional[] profissionais = new Profissional[] { new Profissional("Profissional 1"), new Profissional("Profissional 2") };
        ConsultaController consultaController = new ConsultaController();  // Aqui você pode instanciar seu controller adequadamente

        // Inicializando a tela
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AgendarConsultaView(consultaController, pacientes, profissionais).setVisible(true);
            }
        });
    }
}
