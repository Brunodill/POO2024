package view;

import controller.ProfissionalController;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastroProfissionalView extends JFrame {

    private JTextField txtNome, txtCrm, txtAreaDeAtuacao;

    public CadastroProfissionalView() {
        setTitle("Cadastro de Profissional");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Nome
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(20, 20, 100, 30);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(150, 20, 200, 30);
        add(txtNome);

        // CRM
        JLabel lblCrm = new JLabel("CRM:");
        lblCrm.setBounds(20, 70, 100, 30);
        add(lblCrm);

        txtCrm = new JTextField();
        txtCrm.setBounds(150, 70, 200, 30);
        add(txtCrm);

        // Área de Atuação
        JLabel lblAreaDeAtuacao = new JLabel("Área de Atuação:");
        lblAreaDeAtuacao.setBounds(20, 120, 150, 30);
        add(lblAreaDeAtuacao);

        txtAreaDeAtuacao = new JTextField();
        txtAreaDeAtuacao.setBounds(150, 120, 200, 30);
        add(txtAreaDeAtuacao);

        // Botão de Salvar
        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(150, 200, 100, 30);
        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProfissionalController controller = new ProfissionalController();
                controller.adicionarProfissional(
                    txtNome.getText(),
                    txtCrm.getText(),
                    txtAreaDeAtuacao.getText()
                );
                JOptionPane.showMessageDialog(null, "Profissional cadastrado com sucesso!");
                dispose();
            }
        });
        add(btnSalvar);
    }
}
