package view;

import javax.swing.*;
import dao.ProfissionalDAO;  // Importando o DAO de Profissional
import dao.PacienteDAO;      // Importando o DAO de Paciente
import controller.PacienteController;
import controller.ProfissionalController;
import controller.ConsultaController;
import model.Paciente;
import model.Profissional;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaInicialView extends JFrame {
    private JButton agendarConsultaButton, cadastrarMedicoButton, cadastrarPacienteButton;

    public TelaInicialView() {
        setTitle("Tela Inicial");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Botões
        agendarConsultaButton = new JButton("Agendar Consulta");
        cadastrarMedicoButton = new JButton("Cadastrar Médico");
        cadastrarPacienteButton = new JButton("Cadastrar Paciente");

        // Layout
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        add(agendarConsultaButton);
        add(cadastrarMedicoButton);
        add(cadastrarPacienteButton);

        // Ação do botão "Agendar Consulta"
        agendarConsultaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Criar o DAO para consultas e passá-lo para o controller
                ConsultaDAO consultaDAO = new ConsultaDAO();
                ConsultaController consultaController = new ConsultaController(consultaDAO);
                Paciente[] pacientes = {};  // Preencher com pacientes reais
                Profissional[] profissionais = {};  // Preencher com profissionais reais
                new AgendarConsultaView(consultaController, pacientes, profissionais).setVisible(true);
            }
        });

        // Ação do botão "Cadastrar Médico"
        cadastrarMedicoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProfissionalDAO profissionalDAO = new ProfissionalDAO();  // Instancia o DAO de Profissional
                ProfissionalController profissionalController = new ProfissionalController(profissionalDAO);
                new CadastrarMedicoView(profissionalController).setVisible(true);
            }
        });

        // Ação do botão "Cadastrar Paciente"
        cadastrarPacienteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PacienteDAO pacienteDAO = new PacienteDAO();  // Instancia o DAO de Paciente
                PacienteController pacienteController = new PacienteController(pacienteDAO);
                new CadastrarPacienteView(pacienteController).setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TelaInicialView().setVisible(true);
            }
        });
    }
}
