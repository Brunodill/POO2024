package view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPrincipal extends JFrame {

    public TelaPrincipal() {
        setTitle("Sistema de Clínica");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Botão para Cadastro de Paciente
        JButton btnPaciente = new JButton("Cadastro de Paciente");
        btnPaciente.setBounds(100, 20, 200, 30);
        btnPaciente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CadastroPacienteView().setVisible(true);
            }
        });
        add(btnPaciente);

        // Botão para Cadastro de Profissional
        JButton btnProfissional = new JButton("Cadastro de Profissional");
        btnProfissional.setBounds(100, 70, 200, 30);
        btnProfissional.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CadastroProfissionalView().setVisible(true);
            }
        });
        add(btnProfissional);

        // Botão para Agendamento de Consultas
        JButton btnAgendamento = new JButton("Agendamento de Consultas");
        btnAgendamento.setBounds(100, 120, 200, 30);
        btnAgendamento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AgendamentoConsultaView().setVisible(true);
            }
        });
        add(btnAgendamento);
    }

    public static void main(String[] args) {
        new TelaPrincipal().setVisible(true);
    }
}
