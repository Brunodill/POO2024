package view;

import controller.ProfissionalController;
import model.Profissional;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastrarMedicoView extends JFrame {
    private JTextField nomeField, crmField, areaAtuacaoField;
    private JButton salvarButton;

    private ProfissionalController profissionalController;

    public CadastrarMedicoView(ProfissionalController profissionalController) {
        this.profissionalController = profissionalController;

        setTitle("Cadastrar Médico");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Componentes de entrada
        nomeField = new JTextField(20);
        crmField = new JTextField(10);
        areaAtuacaoField = new JTextField(20);
        salvarButton = new JButton("Salvar");

        // Layout
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(new JLabel("Nome:"));
        add(nomeField);
        add(new JLabel("CRM:"));
        add(crmField);
        add(new JLabel("Área de Atuação:"));
        add(areaAtuacaoField);
        add(salvarButton);

        // Ação do botão Salvar
        salvarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = nomeField.getText();
                String crm = crmField.getText();
                String areaAtuacao = areaAtuacaoField.getText();

                Profissional profissional = new Profissional();
                profissional.setNome(nome);
                profissional.setCRM(crm);
                profissional.setAreaDeAtuacao(areaAtuacao);

                profissionalController.cadastrarProfissional(nome, crm, areaAtuacao);
                JOptionPane.showMessageDialog(CadastrarMedicoView.this, "Médico cadastrado com sucesso!");
                dispose(); // Fechar a janela
            }
        });
    }
}
