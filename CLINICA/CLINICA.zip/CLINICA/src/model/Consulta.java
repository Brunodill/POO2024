package model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Consulta {
    private int id;
    private LocalDate data;
    private LocalTime hora;
    private int pacienteId;
    private int profissionalId;
    private String motivo;

    // Construtor vazio
    public Consulta() {
    }

    // Construtor com todos os campos
    public Consulta(int id, LocalDate data, LocalTime hora, int pacienteId, int profissionalId, String motivo) {
        this.id = id;
        this.data = data;
        this.hora = hora;
        this.pacienteId = pacienteId;
        this.profissionalId = profissionalId;
        this.motivo = motivo;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public int getPacienteId() {
        return pacienteId;
    }

    public void setPacienteId(int pacienteId) {
        this.pacienteId = pacienteId;
    }

    public int getProfissionalId() {
        return profissionalId;
    }

    public void setProfissionalId(int profissionalId) {
        this.profissionalId = profissionalId;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
}
