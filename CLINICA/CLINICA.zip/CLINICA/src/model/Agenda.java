package model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Agenda {
    private int id;
    private LocalDate dia;
    private LocalTime hora;
    private int profissionalId;
    private boolean disponibilidade;

    public Agenda() {
    }

    public Agenda(int id, LocalDate dia, LocalTime hora, int profissionalId, boolean disponibilidade) {
        this.id = id;
        this.dia = dia;
        this.hora = hora;
        this.profissionalId = profissionalId;
        this.disponibilidade = disponibilidade;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getDia() {
        return dia;
    }

    public void setDia(LocalDate dia) {
        this.dia = dia;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public int getProfissionalId() {
        return profissionalId;
    }

    public void setProfissionalId(int profissionalId) {
        this.profissionalId = profissionalId;
    }

    public boolean isDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
}
