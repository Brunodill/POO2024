package model;

public class Prontuario {
    private String dadosDoPaciente;
    private String historico;
    private String diagnostico;
    private String prescricao;

    // Getters e Setters
    public String getDadosDoPaciente() {
        return dadosDoPaciente;
    }

    public void setDadosDoPaciente(String dadosDoPaciente) {
        this.dadosDoPaciente = dadosDoPaciente;
    }

    public String getHistorico() {
        return historico;
    }

    public void setHistorico(String historico) {
        this.historico = historico;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getPrescricao() {
        return prescricao;
    }

    public void setPrescricao(String prescricao) {
        this.prescricao = prescricao;
    }
}
