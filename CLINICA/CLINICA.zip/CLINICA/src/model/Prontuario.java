package model;

public class Prontuario {
    private int id;
    private int pacienteId;
    private String dadosDoPaciente;
    private String historico;
    private String diagnostico;
    private String prescricao;

    public Prontuario() {
    }

    public Prontuario(int id, int pacienteId, String dadosDoPaciente, String historico, String diagnostico, String prescricao) {
        this.id = id;
        this.pacienteId = pacienteId;
        this.dadosDoPaciente = dadosDoPaciente;
        this.historico = historico;
        this.diagnostico = diagnostico;
        this.prescricao = prescricao;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPacienteId() {
        return pacienteId;
    }

    public void setPacienteId(int pacienteId) {
        this.pacienteId = pacienteId;
    }

    public String getDadosDoPaciente() {
        return dadosDoPaciente;
    }

    public void setDadosDoPaciente(String dadosDoPaciente) {
        this.dadosDoPaciente = dadosDoPaciente;
    }

    public String getHistorico() {
        return historico;
    }

    public void setHistorico(String historico) {
        this.historico = historico;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getPrescricao() {
        return prescricao;
    }

    public void setPrescricao(String prescricao) {
        this.prescricao = prescricao;
    }
}
