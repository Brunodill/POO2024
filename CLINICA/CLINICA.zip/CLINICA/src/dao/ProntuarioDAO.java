package dao;

import model.Prontuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProntuarioDAO {

    // Inserir novo prontuário
    public void inserir(Prontuario prontuario) {
        String sql = "INSERT INTO Prontuario (paciente_id, dadosDoPaciente, historico, diagnostico, prescricao) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, prontuario.getPacienteId());
            stmt.setString(2, prontuario.getDadosDoPaciente());
            stmt.setString(3, prontuario.getHistorico());
            stmt.setString(4, prontuario.getDiagnostico());
            stmt.setString(5, prontuario.getPrescricao());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Listar todos os prontuários
    public List<Prontuario> listarTodos() {
        List<Prontuario> prontuarios = new ArrayList<>();
        String sql = "SELECT * FROM Prontuario";
        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Prontuario prontuario = new Prontuario();
                prontuario.setId(rs.getInt("id"));
                prontuario.setPacienteId(rs.getInt("paciente_id"));
                prontuario.setDadosDoPaciente(rs.getString("dadosDoPaciente"));
                prontuario.setHistorico(rs.getString("historico"));
                prontuario.setDiagnostico(rs.getString("diagnostico"));
                prontuario.setPrescricao(rs.getString("prescricao"));
                prontuarios.add(prontuario);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prontuarios;
    }
}
