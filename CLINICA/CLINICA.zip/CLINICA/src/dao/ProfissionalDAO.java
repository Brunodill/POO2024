package dao;

import model.Profissional;
import java.util.HashMap;
import java.util.Map;

public class ProfissionalDAO {
    private Map<String, Profissional> profissionais = new HashMap<>();

    public void salvar(Profissional profissional) {
        profissionais.put(profissional.getCRM(), profissional);
        System.out.println("Profissional salvo: " + profissional.getNome());
    }

    public Profissional buscarPorCRM(String CRM) {
        return profissionais.get(CRM);
    }

    public void atualizar(Profissional profissional) {
        if (profissionais.containsKey(profissional.getCRM())) {
            profissionais.put(profissional.getCRM(), profissional);
            System.out.println("Profissional atualizado: " + profissional.getNome());
        }
    }

    public void remover(String CRM) {
        profissionais.remove(CRM);
        System.out.println("Profissional removido: " + CRM);
    }
}
