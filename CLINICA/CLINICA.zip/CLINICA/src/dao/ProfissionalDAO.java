package dao;

import model.Profissional;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProfissionalDAO {

    // Inserir novo profissional
    public void inserir(Profissional profissional) {
        String sql = "INSERT INTO Profissional (nome, crm, areaDeAtuacao) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, profissional.getNome());
            stmt.setString(2, profissional.getCrm());
            stmt.setString(3, profissional.getAreaDeAtuacao());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Listar todos os profissionais
    public List<Profissional> listarTodos() {
        List<Profissional> profissionais = new ArrayList<>();
        String sql = "SELECT * FROM Profissional";
        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Profissional profissional = new Profissional();
                profissional.setId(rs.getInt("id"));
                profissional.setNome(rs.getString("nome"));
                profissional.setCrm(rs.getString("crm"));
                profissional.setAreaDeAtuacao(rs.getString("areaDeAtuacao"));
                profissionais.add(profissional);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return profissionais;
    }

    // Atualizar profissional
    public void atualizar(Profissional profissional) {
        String sql = "UPDATE Profissional SET nome = ?, crm = ?, areaDeAtuacao = ? WHERE id = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, profissional.getNome());
            stmt.setString(2, profissional.getCrm());
            stmt.setString(3, profissional.getAreaDeAtuacao());
            stmt.setInt(4, profissional.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Excluir profissional
    public void excluir(int id) {
        String sql = "DELETE FROM Profissional WHERE id = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
