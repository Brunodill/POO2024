package dao;

import model.Paciente;
import java.util.HashMap;
import java.util.Map;

public class PacienteDAO {
    private Map<String, Paciente> pacientes = new HashMap<>();

    public void salvar(Paciente paciente) {
        pacientes.put(paciente.getEmail(), paciente);
        System.out.println("Paciente salvo: " + paciente.getNome());
    }

    public Paciente buscarPorEmail(String email) {
        return pacientes.get(email);
    }

    public void atualizar(Paciente paciente) {
        if (pacientes.containsKey(paciente.getEmail())) {
            pacientes.put(paciente.getEmail(), paciente);
            System.out.println("Paciente atualizado: " + paciente.getNome());
        }
    }

    public void remover(String email) {
        pacientes.remove(email);
        System.out.println("Paciente removido: " + email);
    }
}

