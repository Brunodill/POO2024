package dao;

import model.Agenda;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AgendaDAO {

    // Inserir nova agenda
    public void inserir(Agenda agenda) {
        String sql = "INSERT INTO Agenda (dia, hora, profissional_id, disponibilidade) VALUES (?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(agenda.getDia()));
            stmt.setTime(2, Time.valueOf(agenda.getHora()));
            stmt.setInt(3, agenda.getProfissionalId());
            stmt.setBoolean(4, agenda.isDisponibilidade());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Listar todos os registros de agenda
    public List<Agenda> listarTodas() {
        List<Agenda> agendas = new ArrayList<>();
        String sql = "SELECT * FROM Agenda";
        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Agenda agenda = new Agenda();
                agenda.setId(rs.getInt("id"));
                agenda.setDia(rs.getDate("dia").toLocalDate());
                agenda.setHora(rs.getTime("hora").toLocalTime());
                agenda.setProfissionalId(rs.getInt("profissional_id"));
                agenda.setDisponibilidade(rs.getBoolean("disponibilidade"));
                agendas.add(agenda);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return agendas;
    }

    // Atualizar agenda
    public void atualizar(Agenda agenda) {
        String sql = "UPDATE Agenda SET dia = ?, hora = ?, profissional_id = ?, disponibilidade = ? WHERE id = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(agenda.getDia()));
            stmt.setTime(2, Time.valueOf(agenda.getHora()));
            stmt.setInt(3, agenda.getProfissionalId());
            stmt.setBoolean(4, agenda.isDisponibilidade());
            stmt.setInt(5, agenda.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Excluir agenda
    public void excluir(int id) {
        String sql = "DELETE FROM Agenda WHERE id = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
	