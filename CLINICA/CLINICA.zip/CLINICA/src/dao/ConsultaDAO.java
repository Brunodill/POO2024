package dao;

import model.Consulta;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAO {

    private Connection connection;

    // Construtor para conectar ao banco de dados
    public ConsultaDAO() {
        try {
            this.connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao conectar ao banco de dados", e);
        }
    }

    // Método para inserir uma nova consulta
    public void inserir(Consulta consulta) {
        String sql = "INSERT INTO Consulta (data, hora, paciente_id, profissional_id, motivo) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(consulta.getData()));
            stmt.setTime(2, Time.valueOf(consulta.getHora()));
            stmt.setInt(3, consulta.getPacienteId());
            stmt.setInt(4, consulta.getProfissionalId());
            stmt.setString(5, consulta.getMotivo());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao agendar consulta", e);
        }
    }

    // Método para listar todas as consultas
    public List<Consulta> listarTodas() {
        List<Consulta> consultas = new ArrayList<>();
        String sql = "SELECT * FROM Consulta";

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Consulta consulta = new Consulta();
                consulta.setId(rs.getInt("id"));
                consulta.setData(rs.getDate("data").toLocalDate());
                consulta.setHora(rs.getTime("hora").toLocalTime());
                consulta.setPacienteId(rs.getInt("paciente_id"));
                consulta.setProfissionalId(rs.getInt("profissional_id"));
                consulta.setMotivo(rs.getString("motivo"));

                consultas.add(consulta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao listar consultas", e);
        }

        return consultas;
    }

    // Método para atualizar uma consulta existente
    public void atualizar(Consulta consulta) {
        String sql = "UPDATE Consulta SET data = ?, hora = ?, paciente_id = ?, profissional_id = ?, motivo = ? WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, Date.valueOf(consulta.getData()));
            stmt.setTime(2, Time.valueOf(consulta.getHora()));
            stmt.setInt(3, consulta.getPacienteId());
            stmt.setInt(4, consulta.getProfissionalId());
            stmt.setString(5, consulta.getMotivo());
            stmt.setInt(6, consulta.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao atualizar consulta", e);
        }
    }

    // Método para excluir uma consulta
    public void excluir(int id) {
        String sql = "DELETE FROM Consulta WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao excluir consulta", e);
        }
    }
}
