package dao;

import model.Consulta;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAO {
    private List<Consulta> consultas = new ArrayList<>();

    public void salvar(Consulta consulta) {
        consultas.add(consulta);
        System.out.println("Consulta salva com paciente: " + consulta.getPaciente().getNome());
    }

    public List<Consulta> listar() {
        return consultas;
    }
}

